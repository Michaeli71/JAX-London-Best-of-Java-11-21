package exercises.part3;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 *
 * @author Michael Inden
 *
 * Copyright 2023 by Michael Inden
 */
public class Exercise04_Records 
{
	class Square 
	{
		public final double sideLength;
	
		public Square(final double sideLength) 
		{
			this.sideLength = sideLength;
		}
	}
	
	class Circle 
	{
		public final double radius;
	
		public Circle(final double radius) 
		{
			this.radius = radius;
		}
	}
}
