package exercises.part3;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise06_instanceof 
{
	public static void main(String[] args) 
	{	
		Object obj ="BITTE ein BIT";
		
		if (obj instanceof String) 
		{
			final String str = (String)obj; 
			if (str.contains("BITTE"))
			{
		         System.out.println("It contains the magic word!");
		    }
		}
	}
}
