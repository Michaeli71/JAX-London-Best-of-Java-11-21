package exercises.part1;

import java.util.stream.Stream;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise05d_Strings 
{
	public static void main(String[] args) 
	{
		Stream.of(2,4,7,3,1,9,5); // TODO
		
		Stream.of(2,4,7,3,1,9,5); // TODO
	}
}
