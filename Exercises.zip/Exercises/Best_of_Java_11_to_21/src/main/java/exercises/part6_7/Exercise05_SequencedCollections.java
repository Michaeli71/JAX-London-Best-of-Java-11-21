package exercises.part6_7;

import java.util.ArrayList;
import java.util.List;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise05_SequencedCollections
{
    public static void main(String[] args)
    {
        List<Integer> primeNumbers = new ArrayList<>();
        primeNumbers.add(3); // [3]
        // TODO: add 2
        primeNumbers.addAll(List.of(5, 7, 11));
        // TODO: add 13

        System.out.println(primeNumbers); // [2, 3, 5, 7, 11, 13]
        // TODO print first and last element
        // TODO print reverser order

        // TODO: add 17 as last
        System.out.println(primeNumbers); // [2, 3, 5, 7, 11, 13, 17]
        // TODO print reverser order
    }
}