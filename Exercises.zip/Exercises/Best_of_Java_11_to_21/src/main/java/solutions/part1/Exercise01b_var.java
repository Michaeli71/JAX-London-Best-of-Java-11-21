package solutions.part1;

import java.util.Map;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise01b_var 
{
	public static void main(String[] args) 
	{
		funWithVar();
	}

	static void funWithVar()
	{
		Map<String, Integer> personsAndAges = Map.of("Tim", 47, "Tom", 7, "Mike", 47);
		var personsAndAges2 = Map.of("Tim", 47, "Tom", 7, "Mike", 47);
	}

}
