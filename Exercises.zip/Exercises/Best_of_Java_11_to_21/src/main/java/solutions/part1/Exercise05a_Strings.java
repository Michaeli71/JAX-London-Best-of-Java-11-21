package solutions.part1;

import java.util.function.Function;
import java.util.stream.Stream;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise05a_Strings 
{
	public static void main(String[] args) 
	{
		Function<Integer, String> mapper = num -> ("" + num).repeat(num);
		
		Stream.of(2,4,7,3,1,9,5).map(mapper).
		                         forEach(System.out::println);
				
        var coffeePot = """ 
                        _.._..,_,_
                        (          )
                         ]~,"-.-~~[
                       .=])' (;  ([
                       | ]:: '    [
                       '=]): .)  ([
                         |:: '    |
                          ~~----~~""";
        System.out.println(coffeePot);
        
	}	
}