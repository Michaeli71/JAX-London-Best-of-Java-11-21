package solutions.part1;

import java.util.ArrayList;
import java.util.List;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise01c_var 
{
	public static void main(String[] args) 
	{
		funWithVar();
	}

	static void funWithVar()
	{
		List<String> names = new ArrayList<>(); // Achtung: nicht direkt durh var ersetzbar
		var names1 = new ArrayList<String>();   // erfordert das einfügen ds Typs auf der rechten Seite
		var names2 = new ArrayList<String>();
	}
}
