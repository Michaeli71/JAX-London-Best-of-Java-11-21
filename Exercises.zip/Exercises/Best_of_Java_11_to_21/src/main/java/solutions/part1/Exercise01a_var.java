package solutions.part1;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise01a_var 
{
	public static void main(String[] args) 
	{
		funWithVar();
	}

	static void funWithVar()
	{
		var name = "Mike";
		var age = 47;
		
		System.out.println(String.format("name: %s, age: %s", name.getClass().getSimpleName(), 
				((Object)age).getClass().getSimpleName()));
		
	}
}
