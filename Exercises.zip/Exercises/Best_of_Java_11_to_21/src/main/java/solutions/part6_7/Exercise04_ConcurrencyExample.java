package solutions.part6_7;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.StructuredTaskScope;
import java.util.concurrent.StructuredTaskScope.Subtask;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise04_ConcurrencyExample {

    public static void main(String[] args) throws ExecutionException, InterruptedException {

        executeTasks(false);

        executeTasks(true);
    }

    private static void executeTasks(boolean forceFailure) throws InterruptedException, ExecutionException {

        try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {

            Subtask<String> task1 = scope.fork(() -> {
                return "1";
            });
            Subtask<String> task2 = scope.fork(() -> {
                if (forceFailure)
                    throw new IllegalStateException("FORCED BUG");

                return "2";
            });
            Subtask<String> task3 = scope.fork(() -> {
                return "3";
            });

            scope.join();
            scope.throwIfFailed();

            System.out.println(task1.get());
            System.out.println(task2.get());
            System.out.println(task3.get());
        }
    }
}
