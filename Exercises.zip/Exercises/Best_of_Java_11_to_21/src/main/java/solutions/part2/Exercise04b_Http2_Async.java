package solutions.part2;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandler;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise04b_Http2_Async
{
    public static void main(final String[] args) throws Exception
    {
        var uri = new URI("https://www.oracle.com/");

        var request = HttpRequest.newBuilder(uri).GET().build();
        var asString = HttpResponse.BodyHandlers.ofString();

        var httpClient = HttpClient.newHttpClient();
        final CompletableFuture<HttpResponse<String>> asyncResponse = 
                                                      httpClient.sendAsync(request, 
                                                                           asString);
        
        asyncResponse.thenAccept(response -> printResponseInfo(response)).
                      orTimeout(2, TimeUnit.SECONDS).
                      exceptionally(th -> {
                          asyncResponse.cancel(true);
                          System.err.println("timeout");
                          return null;
                      });

//        waitForCompletion();
//        if (asyncResponse.isDone())
//        {
//            final HttpResponse<String> response = asyncResponse.get();
//            printResponseInfo(response);
//        }
//        else
//        {
//            asyncResponse.cancel(true);
//            System.err.println("timeout");
//        }
        
        Thread.sleep(5_000);
    }

    private static void waitForCompletion() throws InterruptedException
    {
        for (int i = 0; i < 10; i++)
        {
            System.out.println("Step " + i);
            Thread.sleep(200);
        }
    }

    private static void printResponseInfo(final HttpResponse<String> response)
    {
        var responseCode = response.statusCode();
        var responseBody = response.body();

        System.out.println("Status: " + responseCode);
        System.out.println("Body:   " + responseBody);
    }
}
