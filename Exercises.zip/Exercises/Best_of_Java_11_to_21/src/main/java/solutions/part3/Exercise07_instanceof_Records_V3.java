package solutions.part3;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise07_instanceof_Records_V3 
{
	// Verbesserung durch Anwenden von Polymorphie und Nutzen des Basistyps in der Signatur
	public double computeArea(final BaseFigure figure) 
	{
		return figure.calcArea();
	}
	
	
	interface BaseFigure
	{
		double calcArea();
	}
	
	record Square(double sideLength) implements BaseFigure {

		@Override
		public double calcArea() {
			return sideLength * sideLength;
		}
	}

	record Circle(double radius) implements BaseFigure 
	{
		@Override
		public double calcArea() 
		{
			return radius * radius * Math.PI;
		}
	}

	// Rectangle
	record Rectangle(double width, double height) implements BaseFigure {

		@Override
		public double calcArea() {
			return width * height;
		}
	}
}
