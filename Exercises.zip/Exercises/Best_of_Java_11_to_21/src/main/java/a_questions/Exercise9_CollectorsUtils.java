package a_questions;

import java.util.function.Predicate;
import java.util.stream.Collector;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise9_CollectorsUtils 
{
	public static <T, A, R> Collector<T, A, R> filtering(final Predicate<? super T> filter, 
			                                             final Collector<T, A, R> collector) 
	{
		  return Collector.of(
		      collector.supplier(),
		      
		      // TRICK
		      (accumulator, input) -> {
		         if (filter.test(input)) {
		            collector.accumulator().accept(accumulator, input);
		         }
		      },		      
		      
		      collector.combiner(),
		      collector.finisher());
	}
}
