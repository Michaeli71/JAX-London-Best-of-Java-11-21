package a_questions;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 *
 * @author Michael Inden
 *
 * Copyright 2023 by Michael Inden
 */
public class TextBlockHelp {

    public static void main(String[] args) {
        String multiLineStringOld = """
            THIS IS
            A MULTI
            LINE STRING
            WITH A BACKSLASH \\
            """;
        System.out.println(multiLineStringOld);
    }

}
