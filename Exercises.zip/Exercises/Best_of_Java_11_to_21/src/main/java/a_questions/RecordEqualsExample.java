package a_questions;

import java.util.Objects;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public record RecordEqualsExample(String name, int age)
{
    // ACHTUNG: DO NOT DO IT AT HOME :-)
    
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RecordEqualsExample other = (RecordEqualsExample) obj;
        return Objects.equals(name, other.name);
    }

    public static void main(String[] args)
    {
        var p1 = new RecordEqualsExample("Peter", 72);
        var p2 = new RecordEqualsExample("Peter", 27);
        
        System.out.println(p1.equals(p2));
    }
}
