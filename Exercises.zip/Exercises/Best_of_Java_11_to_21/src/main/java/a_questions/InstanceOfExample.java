package a_questions;


/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
// FOLIEN!!!
public class InstanceOfExample {

	public static void main(String[] args) {
		
	    Object obj2 = "BACSGsJAHG";
	    
        if (obj2 instanceof String) 
        {
            String str2 = (String)obj2;
            if (str2.length() > 5 && str2.startsWith("BA"))
            {
                System.out.println("Länge: " + str2.length());                
            }
        }
        
	    if (obj2 instanceof String str2 && str2.length() > 5 && str2.startsWith("BA"))
	    {
	        //str2 ="THOMAS_jashjadhkjadhj";
	        System.out.println("Länge: " + str2.length());
	    }
	}
}
