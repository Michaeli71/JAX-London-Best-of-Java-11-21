package b_slides.java19.jep405_record_patterns;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Jep405_InstanceofRecordMatchingAdvanced
{    
    record Point(int x, int y) {}
    
    enum Color { RED, GREEN, BLUE }
    record ColoredPoint(Point p, Color c) {}
    record Rectangle(ColoredPoint upperLeft, ColoredPoint lowerRight) {}

    static void printColorOfUpperLeftPoint(Rectangle rect) 
    {
        if (rect instanceof Rectangle(ColoredPoint(Point p, Color c), ColoredPoint(Point p2, Color c2)))
        {
            System.out.println(c);
            System.out.println(c2);
        }
    }

    static void printXCoordOfUpperLeftPointWithPatterns(Rectangle rect) 
    {
        if (rect instanceof Rectangle(ColoredPoint(Point(var x, var y), var color),
                                      var lr)) 
        {
             System.out.println("Upper-left corner x and color: " + x + " / "  + color);
        }
    }

    public static void main(final String[] args) 
    {
        ColoredPoint ul = new ColoredPoint(new Point(8, 5), Color.RED);
        ColoredPoint lr = new ColoredPoint(new Point(4, 3), Color.BLUE);

        printColorOfUpperLeftPoint(new Rectangle(ul, lr));
        printXCoordOfUpperLeftPointWithPatterns(new Rectangle(ul, lr));
    }
}

