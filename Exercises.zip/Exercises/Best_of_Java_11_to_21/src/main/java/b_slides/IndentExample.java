package b_slides;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class IndentExample 
{
	public static void main(String[] args) 
	{
		var str1 = "first_line\nsecond_line\nlast_line"; 
		System.out.println(str1.length()); 
		
		var str2 = str1.indent(0); 
		System.out.println(str2.length()); 
	}
}
