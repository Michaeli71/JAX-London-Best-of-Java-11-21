package b_slides;

import java.util.Date;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class RecordImmutabilityExample3
{
    public static void main(String[] args)  
    {
		record DateRange(Date start, Date end) 
		{
			DateRange
			{
				if (!start.before(end))
					throw new IllegalArgumentException("start >= end");
			}
		}
				
		DateRange range1 = new DateRange(new Date(71,1,7), new Date(71,2,27));
		System.out.println(range1);
		
		range1.start.setTime(new Date(71,6,7).getTime());
		System.out.println(range1);	
    }
}
