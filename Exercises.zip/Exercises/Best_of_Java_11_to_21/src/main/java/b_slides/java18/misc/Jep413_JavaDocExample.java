package b_slides.java18.misc;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Jep413_JavaDocExample
{
    /**
     * The following code shows how to use {@code Optional.isPresent} and
     * {@code Optional.get} in combination
     * 
     * {@snippet :
     * if (optValue.isPresent()) // @highlight substring="isPresent"
     * { 
     *     System.out.println("value: " + optValue.get()); // @highlight substring="get"
     * } }
     */
    public static void newJavaDocExample(String[] args)
    {
        // 
        //
        //
        //
    }
}