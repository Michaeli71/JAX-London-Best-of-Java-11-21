package b_slides.java18.jep420_switch;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class SwitchSpecialCasesExample
{
    interface Shape {}

    record Rectangle() implements Shape {}
    record Triangle()  implements Shape { int calculateArea() { return 7271; } }

    /*
    static void testTriangleAndString(Object obj)
    {
        switch (obj)
        {
            case Triangle t && t.calculateArea() > 7000 ->
                    System.out.println("Large triangle");
            case String str && str.startsWith("INFO") ->
                    System.out.println("just an info");
            default ->
                    System.out.println("Something else: " + obj);
        }
    }

    static void testTriangleAndString2(Object obj)
    {
        switch (obj)
        {
            case Triangle t && t.calculateArea() > 7000 ->
                    System.out.println("Large triangle");
            case String str && str.startsWith("INFO") && str.contains("SPECIAL") ->
                    System.out.println("a very special info");
            case String str && str.startsWith("INFO") ->
                    System.out.println("just an info");
            // not detected ...
            case String str && str.startsWith("INFO") && str.contains("SPECIAL") ->
                    System.out.println("a very special info");
            default ->
                    System.out.println("Something else: " + obj);
        }
    }

    public static void main(String[] args)
    {
        testTriangleAndString(Triangle());
        testTriangleAndString("INFO: switch and when");
        testTriangleAndString("INFO: switch and SPECIAL");
        testTriangleAndString2("INFO: switch and SPECIAL");
        testTriangleAndString("Michael");
    }
    */
}

