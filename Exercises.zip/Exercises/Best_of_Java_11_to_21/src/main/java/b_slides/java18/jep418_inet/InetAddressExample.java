package b_slides.java18.jep418_inet;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 *
 * @author Michael Inden
 *
 * Copyright 2023 by Michael Inden
 */
public class InetAddressExample
{
    public static void main(final String[] args) throws UnknownHostException
    {
        final InetAddress[] addresses = InetAddress.getAllByName("www.dpunkt.de");
        System.out.println("addresses = " + Arrays.toString(addresses));
    }
}
