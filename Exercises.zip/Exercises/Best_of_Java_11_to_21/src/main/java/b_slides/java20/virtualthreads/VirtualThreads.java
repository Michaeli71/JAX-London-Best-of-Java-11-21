package b_slides.java20.virtualthreads;
import java.time.Duration;
import java.util.concurrent.Executors;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 17 / 18 / 19 / 20" sowie
 * die Bücher "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und "Java 21 LTS – Die Neuerungen"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2023 by Michael Inden
 */
public class VirtualThreads
{
    public static void main(String[] args)
    {
    	System.out.println("Start");

        try (var executor = Executors.newVirtualThreadPerTaskExecutor())
        {
            for (int  i = 0; i < 1_000_000; i++)
            {
                final int pos = i;
                executor.submit(() -> {
                    Thread.sleep(Duration.ofSeconds(1));
                    return pos;
                });
            }
        }
        // executor.close() is called implicitly, and waits
        System.out.println("End");
    }
}
