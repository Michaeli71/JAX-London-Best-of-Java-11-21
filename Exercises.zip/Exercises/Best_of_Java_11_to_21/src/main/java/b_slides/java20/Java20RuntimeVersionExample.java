package b_slides.java20;

import javax.lang.model.SourceVersion;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Java20RuntimeVersionExample
{
    public static void main(String[] args)
    {
        System.out.println("Runtime required for this: " + SourceVersion.RELEASE_20.runtimeVersion());
        System.out.println("latest: " + SourceVersion.latest());
        System.out.println("valueOf: " + SourceVersion.valueOf("RELEASE_20"));
    }
}