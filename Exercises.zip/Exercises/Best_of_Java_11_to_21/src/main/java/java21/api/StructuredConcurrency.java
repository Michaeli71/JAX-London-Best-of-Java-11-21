package java21.api;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.StructuredTaskScope;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class StructuredConcurrency
{
    public static void main(String[] args) throws ExecutionException, InterruptedException
    {
        System.out.println("Start");

        System.out.println("sync:" + handleSynchronously(4711L));
        System.out.println("old style:" + handleOldStyle(4711L));
        System.out.println("new style:" + handle(4711L));

        System.out.println("End");
    }

    static Response handleSynchronously(Long userId)
    {
        String user = findUser(userId);
        Integer order = fetchOrder(userId);

        return new Response(user, order);
    }

    static Response handleOldStyle(Long userId) throws ExecutionException, InterruptedException
    {
        var exectuorService = Executors.newCachedThreadPool();

        var userNameFuture = exectuorService.submit(() -> findUser(userId));
        var orderNoFuture = exectuorService.submit(() -> fetchOrder(userId));

        var user = userNameFuture.get();   // Join findUser
        var order = orderNoFuture.get();  // Join fetchOrder

        return new Response(user, order);
    }

    static Response handle(Long userId) throws ExecutionException, InterruptedException
    {
        try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
            var userNameFuture  = scope.fork(() -> findUser(userId));
            var orderNoFuture = scope.fork(() -> fetchOrder(userId));

            scope.join();          // Join both forks
            scope.throwIfFailed(); // ... and propagate errors

            // Here, both forks have succeeded, so compose their results
            return new Response(userNameFuture.get(), orderNoFuture.get());
        }
    }

    static String findUser(Long userId)
    {
        return "Michael";
    }

    static Integer fetchOrder(Long userId)
    {
        return 42;
    }
    record Response(String userName, Integer orderNo) { }
}
