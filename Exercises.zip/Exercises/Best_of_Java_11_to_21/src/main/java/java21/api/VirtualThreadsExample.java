package java21.api;
import java.time.Duration;
import java.util.concurrent.Executors;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class VirtualThreadsExample
{
    public static void main(String[] args)
    {
    	System.out.println("Start");

        try (var executor = Executors.newVirtualThreadPerTaskExecutor())
        {
            for (int  i = 0; i < 100_000; i++)
            {
                final int pos = i;
                executor.submit(() -> {
                    Thread.sleep(Duration.ofSeconds(1));
                    return pos;
                });
            }
        }
        // executor.close() is called implicitly, and waits
        System.out.println("End");
    }
}
