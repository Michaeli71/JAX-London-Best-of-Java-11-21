package java21.api;

import java.util.Arrays;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class MiscStringRelated 
{
    public static void main(final String[] args) 
    {
        var buffer = new StringBuffer();
        buffer.repeat(12345, 5);
        buffer.repeat(721971, 5);
        System.out.println(buffer);

        var booAndFoo = "boo:::and::foo";
        String[] splits = booAndFoo.splitWithDelimiters(":+", 3);
        System.out.println("splits = " + Arrays.toString(splits));
    }
}
